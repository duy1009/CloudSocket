STATUS = {
    0:"Success!",
    1:"ERROR: Cannot save because the file already exists",
    2:"File exists",
    3:"No file",
}

HEADER = 5